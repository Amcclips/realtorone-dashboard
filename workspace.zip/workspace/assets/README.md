# RealtorOne CRM Logo Assets

This folder contains official brand assets for content generation.

## Files

| File | Description | Use Case |
|------|-------------|----------|
| `realtorone-logo-dark.png` | Logo on dark green background | Social posts, dark themes, stories |
| `realtorone-logo-light.png` | Logo on white background | Blog headers, light backgrounds, print |
| `BRAND_GUIDELINES.md` | Full brand guidelines | Color codes, usage rules |

## Brand Colors
- **Primary Green:** #0D3B2E
- **Accent Gold:** #F4B942
- **White:** #FFFFFF

## Quick Reference
- CTA Buttons: Gold background (#F4B942), dark green text (#0D3B2E)
- Headers: Dark green background (#0D3B2E), white or gold text
- Links: Gold accent color
