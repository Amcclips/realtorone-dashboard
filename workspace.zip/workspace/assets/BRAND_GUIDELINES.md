# RealtorOne CRM Brand Guidelines

## Logo Assets

### Primary Logo (Dark Background)
- **File:** `assets/realtorone-logo-dark.png`
- **Use:** Dark backgrounds, social media posts with dark themes, email headers
- **Background:** Dark forest green (#0D3B2E)

### Secondary Logo (Light Background)  
- **File:** `assets/realtorone-logo-light.png`
- **Use:** Light backgrounds, white paper/blog headers, print materials
- **Background:** White (#FFFFFF)

## Brand Colors

| Color | Hex Code | RGB | Usage |
|-------|----------|-----|-------|
| **Primary Green** | `#0D3B2E` | rgb(13, 59, 46) | Headers, backgrounds, primary buttons |
| **Accent Gold** | `#F4B942` | rgb(244, 185, 66) | CTAs, highlights, emphasis text |
| **White** | `#FFFFFF` | rgb(255, 255, 255) | Text on dark backgrounds, clean spaces |
| **Dark Green Text** | `#0D3B2E` | rgb(13, 59, 46) | Body text on light backgrounds |

## Logo Usage in Content

### Blog Articles
- Include logo at top of article (light version for white background)
- Use brand colors for headers and CTA buttons

### Email Newsletters
- Logo in header (light version, 150-200px width)
- Primary green for header background
- Gold accent for CTA buttons

### Social Media Posts

**Instagram:**
- Logo in carousel first slide or story highlight
- Use dark logo version for posts with dark backgrounds
- Brand colors for text overlays

**Facebook:**
- Logo as featured image or in post creative
- Dark green background with gold text for quote graphics

**LinkedIn:**
- Logo in header image for articles
- Professional, clean usage with light logo version

**X/Twitter:**
- Logo in profile-optimized size for tweet images
- Dark version for dark mode compatibility

**Reddit:**
- No direct logo usage in posts (follows community-first rule)
- Logo only in bio/flair where permitted

### Visual Content Guidelines
- **CTA Buttons:** Gold (#F4B942) background with dark green (#0D3B2E) text
- **Headers:** Dark green (#0D3B2E) background with white or gold text
- **Highlights/Stats:** Gold (#F4B942) for emphasis
- **Links:** Gold (#F4B942) underlined on dark, dark green on light

## Color Contrast Ratios
- White text on Primary Green: WCAG AA compliant ✓
- Dark Green text on White: WCAG AA compliant ✓
- Gold accent on Dark Green: High visibility ✓

## Logo Clear Space
- Maintain minimum clear space of 20px around logo
- Never distort, rotate, or alter logo proportions
- Never place logo on busy/cluttered backgrounds

## File Locations
```
/workspace/assets/
├── realtorone-logo-dark.png    (Dark background version)
└── realtorone-logo-light.png   (Light background version)
```
