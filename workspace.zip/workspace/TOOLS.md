# TOOLS.md - Local Notes

## Content Generation

### Realtor One CRM
- Content schedule: Every Monday
- Markets: US + Nigeria real estate
- Rotation: 4-week cycle (Market News → CRM Tips → Success Stories → Client Education)
- Target keywords: real estate CRM, lead management, property marketing
