# RealtorOne CRM Content Tracking

## Content Format
**Separate content for US and Nigeria markets**
**Each market gets:** Blog + Email + Facebook + Instagram + LinkedIn + X/Twitter + Reddit

## Brand Assets

### Logo Files
| File | Location | Use Case |
|------|----------|----------|
| Dark Logo | `/assets/realtorone-logo-dark.png` | Dark backgrounds, Instagram, social posts |
| Light Logo | `/assets/realtorone-logo-light.png` | Light backgrounds, blogs, email headers |

### Brand Colors
| Color | Hex | Usage |
|-------|-----|-------|
| Primary Green | `#0D3B2E` | Headers, backgrounds, brand identity |
| Accent Gold | `#F4B942` | CTAs, buttons, highlights, emphasis |
| White | `#FFFFFF` | Text on dark, clean spaces |

### Key Links
- **Signup:** https://www.realtoronecrm.com/signup
- **Homepage:** https://www.realtoronecrm.com/

## Current Status

| Week | Theme | Date | US Status | Nigeria Status |
|------|-------|------|-----------|----------------|
| Week 1 | Market News & Trends | 2026-03-29 | ✅ Published | ✅ Published |
| Week 2 | CRM Tips & Productivity | 2026-04-06 | ⏳ Next | ⏳ Next |
| Week 3 | Agent Success Stories | — | ⏳ Pending | ⏳ Pending |
| Week 4 | Client Education Content | — | ⏳ Pending | ⏳ Pending |

## Content Archive

### 2026 - Week 1: Market News & Trends (March 29, 2026)

**🇺🇸 US Market Content (7 pieces):**
| Type | File | Size |
|------|------|------|
| Blog | [2026-03-29-us-week1-blog.md](./2026-03-29-us-week1-blog.md) | ~1,100 words |
| Email | [2026-03-29-us-week1-email.md](./2026-03-29-us-week1-email.md) | Newsletter format |
| Facebook | [2026-03-29-us-week1-facebook.md](./2026-03-29-us-week1-facebook.md) | ~185 words |
| Instagram | [2026-03-29-us-week1-instagram.md](./2026-03-29-us-week1-instagram.md) | ~115 words |
| LinkedIn | [2026-03-29-us-week1-linkedin.md](./2026-03-29-us-week1-linkedin.md) | ~235 words |
| X/Twitter | [2026-03-29-us-week1-twitter.md](./2026-03-29-us-week1-twitter.md) | 3-tweet thread |
| Reddit | [2026-03-29-us-week1-reddit.md](./2026-03-29-us-week1-reddit.md) | ~300 words |

**🇳🇬 Nigeria Market Content (7 pieces):**
| Type | File | Size |
|------|------|------|
| Blog | [2026-03-29-nigeria-week1-blog.md](./2026-03-29-nigeria-week1-blog.md) | ~1,100 words |
| Email | [2026-03-29-nigeria-week1-email.md](./2026-03-29-nigeria-week1-email.md) | Newsletter format |
| Facebook | [2026-03-29-nigeria-week1-facebook.md](./2026-03-29-nigeria-week1-facebook.md) | ~160 words |
| Instagram | [2026-03-29-nigeria-week1-instagram.md](./2026-03-29-nigeria-week1-instagram.md) | ~120 words |
| LinkedIn | [2026-03-29-nigeria-week1-linkedin.md](./2026-03-29-nigeria-week1-linkedin.md) | ~220 words |
| X/Twitter | [2026-03-29-nigeria-week1-twitter.md](./2026-03-29-nigeria-week1-twitter.md) | 3-tweet thread |
| Reddit | [2026-03-29-nigeria-week1-reddit.md](./2026-03-29-nigeria-week1-reddit.md) | ~280 words |

## Next Content Due
**April 6, 2026 — Week 2: RealtorOne CRM Tips & Productivity**

## Rotation Schedule
1. Week 1 → Week 2 → Week 3 → Week 4 → Back to Week 1
2. Generate every Monday at 8:07 AM
3. 7 content pieces per market (14 total)
4. Target: 800-1200 words for blogs, per-spec for social posts

## File Naming Convention
`YYYY-MM-DD-{market}-week{N}-{type}.md`

Markets: `us`, `nigeria`  
Types: `blog`, `email`, `facebook`, `instagram`, `linkedin`, `twitter`, `reddit`

## Weekly Publishing Schedule
- **Monday 8:07 AM:** Generate all content
- **Monday 9:00 AM:** Publish blog articles (use light logo)
- **Monday 9:30 AM:** Send email newsletters via Resend (use light logo)
- **Monday 10:00 AM:** Facebook posts (use dark logo)
- **Monday 10:15 AM:** Instagram posts (use dark logo)
- **Monday 10:30 AM:** LinkedIn posts (use light logo)
- **Monday 10:45 AM:** X/Twitter threads (use dark logo)
- **Monday 11:00 AM:** Reddit posts (no logo in body)
- **All week:** Monitor and reply to comments

## Brand Voice Guidelines
- Confident, bold, top-producer energy
- Empathetic to agent pain points
- Use "you" and "your" constantly
- Never corporate, robotic, or press-release-y

## Marketing Pillars
1. Pain → Solution
2. Social proof
3. FOMO
4. Value-first
5. Clear CTA
