# Long-Term Memory

## Content Projects

### Realtor One CRM Content Generation
- **Markets:** US + Nigeria real estate
- **Frequency:** Weekly (Mondays)
- **Format:** 4-week rotating content calendar
- **Target:** Real estate agents, brokers, property marketers
- **Status:** Active cron job configured
- **Content Tracking:** See `content-tracking.md` for current week and archive

**Latest Content (March 29, 2026):**
- Week 1: Market News & Trends — "US & Nigeria Real Estate Market Pulse: What Agents Need to Know This Week"
- Next: Week 2 (April 6, 2026) — CRM Tips & Productivity Hacks

## User Context

### Preferences
- Real estate marketing focus
- Multi-market content (US + Nigeria)
- Values practical, actionable content
- Wants real market examples, not generic advice

### Projects
- Realtor One CRM content marketing system
